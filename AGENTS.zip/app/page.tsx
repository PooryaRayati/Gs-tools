"use client";

import Header from "@/elements/header";
import Demo from "@/elements/CRS"
import TrustBox from "@/elements/trustBox";
import Footer from "@/elements/footer";
import TableBox from "@/elements/table";


export default function Home() {
  return (
    <div className="">
      <Header />
      <br />
      <div className="flex justify-center">
        <Demo />
      </div>
      <br />
      <br />
      <TrustBox />
      <TableBox/>
      <br /><br /><br />

      <Footer/>
    </div>
  );
}
