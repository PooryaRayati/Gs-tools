"use client";

import { Carousel } from '@mantine/carousel';
import { useRef } from 'react';
import Autoplay from 'embla-carousel-autoplay';

export default function Demo() {
  const list = ["carousel1.webp", "carousel2.webp", "carousel3.webp"]
  const autoplay = useRef(Autoplay({ delay: 4000 }));

  return (
    <Carousel
      className='w-[85%] rounded-4xl'
      withIndicators
      height={440}
      slideSize="100%"
      slideGap={0}
      plugins={[autoplay.current]}
      onMouseEnter={autoplay.current.stop}
      onMouseLeave={() => autoplay.current.play()}
      emblaOptions={{
        dragFree: false,
        loop: true,
        align: "start",
      }}
    >
      {list.map((item) => (
        <Carousel.Slide key={item}>
          <div
            className="flex h-full p-20 items-center justify-center rounded-4xl text-lg text-gray-600 font-bold bg-cover bg-center hover:scale-102 duration-600 ease-in-out"
            style={{ backgroundImage: `url(/images/${item})` }}
          >
            <div className="grndit_box absolute w-full h-full rounded-4xl left-0 backdrop-blur-3xl"></div>
            <button className="see_but flex items-center absolute left-10 bg-white py-2 px-5 rounded-4xl  ease-in-out bottom-6 ">
              مشاهده محصولات
              <svg xmlns="http://www.w3.org/2000/svg" width="1.4em" height="1.4em" viewBox="0 0 24 24">
                <path fill="none" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="m11 5l-7 7l7 7m-7-7h16"></path>
              </svg>
            </button>
            
          </div>
        </Carousel.Slide>
      ))}
    </Carousel>
  );
}



